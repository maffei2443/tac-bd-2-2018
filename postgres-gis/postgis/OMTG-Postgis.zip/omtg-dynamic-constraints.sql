-- Validate the topological relationship between ESTADIO and PAIS
CREATE TRIGGER ESTADIO_PAIS_Within_insert_update_trigger
  AFTER INSERT OR UPDATE ON ESTADIO
  FOR EACH STATEMENT
  EXECUTE PROCEDURE ast_spatialrelationship('ESTADIO', 'geom', 'PAIS', 'geom', 'within');

-- Validate the topological relationship between CIDADE and PAIS
CREATE TRIGGER CIDADE_PAIS_Within_insert_update_trigger
  AFTER INSERT OR UPDATE ON CIDADE
  FOR EACH STATEMENT
  EXECUTE PROCEDURE ast_spatialrelationship('CIDADE', 'geom', 'PAIS', 'geom', 'within');

