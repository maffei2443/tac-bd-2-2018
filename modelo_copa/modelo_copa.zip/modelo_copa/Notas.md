+ pessoa-equipe : obrigatória 1 equipe por pessoa.
+ Razão: só está no banco se tiver participado de copa, e para tal precisa de equipe.

+ jogo-equipe[12]: obrigatória. Preferi a consistência em troca de poder cadastrar o jogo antes de ele ocorrer.

+ PARITIPA(JOGO,COPA) : me parece desnecessário, já que a partir das equipes se obtém esses dados. **PORÉM** deixarei .

+ Conceitualmente, jogo é fraco com Copa... porém, o jogo tendo as equipes, facilmente identifica-se a qual copa ele pertence. Entretanto, há aí um custo por conta das queries.

