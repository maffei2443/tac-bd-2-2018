As queries contidas nesse diretório são **exatamente** as mesmas do diretório pai 
deste, porém com uma formatação mais compacta para que a o *screenshot* tirado
não ficasse muito grande.
